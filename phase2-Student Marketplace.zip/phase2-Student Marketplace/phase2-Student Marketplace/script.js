// script.js

// ========== GLOBAL VARIABLES ========== //
const apiURL = 'https://jsonplaceholder.typicode.com/posts'; // Dummy API for testing
let listings = []; // Array to store fetched marketplace items
let currentPage = 1;
const itemsPerPage = 6;

// ========== FETCH DATA ========== //
async function fetchListings() {
  showLoading();
  try {
    const response = await fetch(apiURL);
    if (!response.ok) throw new Error('Failed to fetch listings.');
    const data = await response.json();
    listings = data.slice(0, 20); // Only use first 20 fake listings
    renderListings();
    hideLoading();
  } catch (error) {
    console.error('Error fetching listings:', error);
    showError('Failed to load listings. Please try again later.');
  }
}

// ========== RENDER LISTINGS ========== //
function renderListings() {
  const container = document.querySelector('.row.g-3');
  if (!container) return;

  container.innerHTML = '';

  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const paginatedListings = listings.slice(start, end);

  paginatedListings.forEach(item => {
    const card = document.createElement('article');
    card.className = 'col-md-4';
    card.innerHTML = `
      <div class="card h-100">
        <div class="card-body">
          <h2 class="h5 card-title">${item.title.substring(0, 20)}</h2>
          <p class="card-text">${item.body.substring(0, 50)}...</p>
          <a href="detail.html?id=${item.id}" class="btn btn-primary">View Details</a>
        </div>
      </div>
    `;
    container.appendChild(card);
  });

  renderPagination();
}

// ========== RENDER PAGINATION ========== //
function renderPagination() {
  const totalPages = Math.ceil(listings.length / itemsPerPage);
  const pagination = document.querySelector('.pagination');
  if (!pagination) return;

  pagination.innerHTML = `
    <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
      <a class="page-link" href="#" onclick="changePage(${currentPage - 1})">Previous</a>
    </li>
  `;

  for (let i = 1; i <= totalPages; i++) {
    pagination.innerHTML += `
      <li class="page-item ${i === currentPage ? 'active' : ''}">
        <a class="page-link" href="#" onclick="changePage(${i})">${i}</a>
      </li>
    `;
  }

  pagination.innerHTML += `
    <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
      <a class="page-link" href="#" onclick="changePage(${currentPage + 1})">Next</a>
    </li>
  `;
}

function changePage(page) {
  currentPage = page;
  renderListings();
}

// ========== SHOW LOADING / ERROR ========== //
function showLoading() {
  const container = document.querySelector('.row.g-3');
  if (container) {
    container.innerHTML = '<div class="text-center w-100"><div class="spinner-border" role="status"></div></div>';
  }
}

function hideLoading() {
  // nothing needed
}

function showError(message) {
  const container = document.querySelector('.row.g-3');
  if (container) {
    container.innerHTML = `<div class="alert alert-danger w-100 text-center">${message}</div>`;
  }
}

// ========== FORM VALIDATION ========== //
function validateForm() {
  const form = document.querySelector('form');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent actual submit

    if (form.checkValidity() === false) {
      e.stopPropagation();
      alert('Please fill all required fields correctly!');
    } else {
      alert('Form looks good! (In Phase 3 you will actually submit)');
    }

    form.classList.add('was-validated');
  });
}

// ========== DETAIL VIEW ========== //
function loadDetailView() {
  const params = new URLSearchParams(window.location.search);
  const itemId = params.get('id');
  if (!itemId) return;

  fetch(`${apiURL}/${itemId}`)
    .then(response => response.json())
    .then(item => {
      document.querySelector('h1.h1').textContent = item.title.substring(0, 20);
      document.querySelector('main .h2:nth-of-type(1) + p').textContent = item.body;
      document.querySelector('main .h2:nth-of-type(2) + p').textContent = 'Electronics'; // Dummy category
    })
    .catch(error => {
      console.error('Error loading detail:', error);
      showError('Could not load item details.');
    });
}

// ========== INITIALIZATION ========== //
document.addEventListener('DOMContentLoaded', () => {
  if (window.location.pathname.includes('index.html')) {
    fetchListings();
  }

  if (window.location.pathname.includes('create.html')) {
    validateForm();
  }

  if (window.location.pathname.includes('detail.html')) {
    loadDetailView();
  }
});
